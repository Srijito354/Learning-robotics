#quaternians: helps determine the orientation of an object in 3d space,
#like cartesian does in 2D space.

#converting the code to a a ros node.
import rclpy
from geometry_msgs.msg import Quaternion #creating an import for publisher message.
rclpy.init()
node=rclpy.create_node('my_first_node')#creating a node

#publisher parameters:
#message: eg:-quaternians to determine the position of the object.
publisher=node.create_publisher(Quaternion, "my_first_publisher_topic", 10)#creating a publisher, with 3 parameters. "Quaternian" is the message type and "my_first_publisher" is the topic name.
#The 3rd parameter being, "qos_value". To be understood later.

#creating a Quaternion object.
D=Quaternion()
#providing orientations and storing them as quaternion values which will be published.
D.x=1.0
D.y=2.0
D.z=3.0
D.w=1.0

#publishing the message type, "Quaternion" of the topic name, "my_first_publisher_topic".
publisher.publish(D)

#print(x,y,z,w)
rclpy.spin(node)